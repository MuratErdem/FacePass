<?php
class Main_controller extends CI_Controller {
function __construct() {
parent::__construct();
$this->load->helper('form');
}
function index() {
$this->load->view('form');
}
}
?>