<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Main extends CI_Controller {
 
function __construct()
{
        parent::__construct();
 
/* Standard Libraries of codeigniter are required */
$this->load->database();
$this->load->helper('url');
/* ------------------ */ 
 
$this->load->library('grocery_CRUD');
 
}
 
public function index()
{
echo "<h1>Welcome to the world of Codeigniter</h1>";//Just an example to ensure that we get into the function
die();
}
    public function person_details()
    {
        $crud = new grocery_CRUD();
        $crud->set_subject('Person Details');
        $crud->set_table('person_details2');
	$crud->set_theme('flexigrid');
        $crud->display_as('fname','First Name');
        $crud->display_as('mname','Middle Name');
        $crud->display_as('lname','Last Name');
        $crud->display_as('id','Unique ID');
        //$crud->unset_edit();
        //$crud->unset_delete();
        //$crud->unset_print();
        //$crud->unset_export();
	$crud->set_field_upload('img_file_path','assets/uploads/files');

        //$crud->set_rules('state','State','required');
        $output = $crud->render();

        $this->_example_output($output);
    }

	public function presence_in_out()
    {
        $crud = new grocery_CRUD();
        $crud->set_subject('Presence');
        $crud->set_table('presence_in_out');
        $crud->display_as('person_id','Name');
	$crud->set_relation('person_id','person_details2','{fname} {mname} {lname}');
	//$crud->set_relation('person_id','person_details2','Employee_no');
	//$crud->field_type('matched_img_path', 'hidden', $matched_img_path);
	$crud->unset_columns(array('matched_img_path_in','matched_img_path_out','face_frame_path'));

	$crud->change_field_type('pre_date','date');
        $crud->unset_edit();

        $crud->unset_add();
        //$crud->unset_delete();
        //$crud->unset_print();
        //$crud->unset_export();
	$crud->set_field_upload('face_img_show_in','assets/images/dump');
	$crud->set_field_upload('face_img_show_out','assets/images/dump');
        $output = $crud->render();

        $this->_example_output($output);

    }
	public function recog_records()
    {
        $crud = new grocery_CRUD();
        $crud->set_subject('Presence');
        $crud->set_table('recog_records');
        $crud->display_as('person_id','Name');
	$crud->set_relation('person_id','person_details2','fname');
	//$crud->set_relation('person_id','person_details2','Employee_no');
	//$crud->field_type('matched_img_path', 'hidden', $matched_img_path);
	$crud->unset_columns(array('matched_img_path'));
	$crud->change_field_type('pre_date','date');
        //$crud->unset_edit();/
        //$crud->unset_delete();
        //$crud->unset_print();
        //$crud->unset_export();
    $crud->unset_edit();

        $crud->unset_add();
	$crud->set_field_upload('face_img_show','assets/images/dump');
        $output = $crud->render();

        $this->_example_output($output);

    }
	

	
	public function camera_entry()
    {
        $crud = new grocery_CRUD();
        $crud->set_subject('Camera List');
        $crud->set_table('camera_master');
      	$crud->display_as('camera_type','Camera ACTIVE=IN INACTIVE=OUT');
	   $crud->display_as('source_URL','URL');

	//$crud->field_type('matched_img_path', 'hidden', $matched_img_path);
        //$crud->unset_edit();/
        //$crud->unset_delete();
        $crud->unset_print();
        $crud->unset_export();
        $output = $crud->render();

        $this->_example_output($output);

    }
	
function _example_output($output = null)
 
{
$this->load->view('our_template.php',$output);    
}
function dashboard($output = null)
 
{
$this->load->view('dashboard.php');    
}
}
 
/* End of file Main.php */
/* Location: ./application/controllers/Main.php */
