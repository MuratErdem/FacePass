<?php
error_reporting(0);
  if(!isset($_SESSION['username']))  
  {
    $redirect_string = "http://localhost/face_pass/index.php/user_authentication/logout";
    header("location:".$redirect_string);
  }
  else
  {
    $pic_path="";
    $user_type="";
    include('db_config.php');
    $sql_query1 = "SELECT * From signup where username='".$_SESSION['username']."'";
    $result_query1 = $conn->query($sql_query1);
    if ($result_query1->num_rows > 0) 
    {
        while($row_query1 = $result_query1->fetch_assoc()) 
        {
            $pic_path=$row_query1['pic_path'];
        }
    }
    $username=$_SESSION['username'];
    $sql_query2 = "SELECT * from signup where username='".$username."'";
    $result_query2 = $conn->query($sql_query2);
    if($result_query2->num_rows > 0)
    {
        while($row_query2 = $result_query2->fetch_assoc())
        {
            $type_id = $row_query2['user_type_id'];
            $sql_query3 = "SELECT * FROM user_type_master where id='".$type_id."'";
            $result_query3 = $conn->query($sql_query3);
            if($result_query3->num_rows > 0)
            {
                while($row_query3 = $result_query3->fetch_assoc())
                {
                    $user_type = $row_query3['type'];
                }
            }
        }
    }
  }
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->

<head>
    <?php 
foreach($css_files as $file): ?>
    <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
 
<?php endforeach; ?>
<?php foreach($js_files as $file): ?>
 
    <script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
 
<style type='text/css'>
body
{
    font-family: Arial;
    font-size: 14px;
}
a {
    color: blue;
    text-decoration: none;
    font-size: 16px;
}
a:hover
{
    text-decoration: underline;
}
@page { size: auto;  margin: 0mm; }

</style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>FacePass</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="<?php echo base_url(); ?>assets/images/logo.png">
    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/logo.png">

    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/normalize.css" >
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/themify-icons.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/cs-skin-elastic.css">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/scss/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>
<body>
        <!-- Left Panel -->
            <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href=""><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Logo"></a>
                <a class="navbar-brand hidden" href=""><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="<?php echo site_url('main/dashboard')?>"> <i class="menu-icon fa fa-dashboard"></i>Dashboard</a>
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                    <?php
                    if($user_type == "Super Admin")
                    {
                    ?>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-laptop"></i>Manage Masters</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><a href='<?php echo site_url('main/person_details')?>'>Manage Known Person Details</a> </li>
                            <li><a href='<?php echo site_url('main/camera_entry')?>'>Manage Cameras</a> </li>
                           

                        </ul>
                    </li>
                    <?php
                    }
                    ?>
                    <li class="menu-item-has-children active dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-table"></i>Attendance</a>
                        <ul class="sub-menu children dropdown-menu">
							
                            <li><i class="fa fa-table"></i><a href="<?php echo site_url('main/presence_in_out')?>">Presence IN OUT</a></li>

                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-th"></i>Records</a>
                        <ul class="sub-menu children dropdown-menu">
                         
                            <li><i class="fa fa-file-text-o"></i><a href="<?php echo site_url('main/recog_records')?>">Recognition Records</a></li>

                        </ul>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->
    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                       
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">User <?php echo $_SESSION['username']; ?>&nbsp&nbsp
                            <img class="user-avatar rounded-circle" src="<?php echo base_url(); ?>assets/uploads/files/<?php echo $pic_path; ?>" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                               

                                <a class="nav-link" href="<?php echo base_url()."index.php/user_authentication/logout"; ?>"><i class="fa fa-power -off"></i>Logout</a>
                        </div>
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"  id="language" aria-haspopup="true" aria-expanded="true">
                            <i class="flag-icon flag-icon-us"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="language" >
                            <div class="dropdown-item">
                                <span class="flag-icon flag-icon-fr"></span>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-es"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-us"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-it"></i>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->
