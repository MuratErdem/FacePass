<?php
include('db_config.php');
include('header.php');

?>

<div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

<?php 
include('footer.php');
?>
<script src="<?php echo base_url(); ?>assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/dashboard.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/widgets.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/lib/vector-map/jquery.vmap.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/lib/vector-map/jquery.vmap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/lib/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/lib/vector-map/country/jquery.vmap.world.js"></script>
   
    
</body>
</html>
